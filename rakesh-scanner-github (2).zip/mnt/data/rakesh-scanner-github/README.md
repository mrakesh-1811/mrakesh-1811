# M Rakesh — Neon Symbol Scanner Avatar

A looping purple/cyan scanning GIF made from a portrait using symbol/dot-matrix rendering.

## Files
- `rakesh_scanner.gif` — animated avatar for GitHub profile README
- `avatar.png` — input portrait used to generate the animation
- `scanner.py` — script to regenerate the GIF
- `rakesh_scanner_preview.png` — still preview

## Regenerate locally
1. Install Python 3 and Pillow: `pip install pillow`
2. Keep `avatar.png` and `scanner.py` in the same folder.
3. Run: `python scanner.py`

## Add to GitHub profile README
Upload `rakesh_scanner.gif` to your profile repository (`mrakesh-1811/mrakesh-1811`) at the repository root, then add:

```html
<div align="center">
  <img src="rakesh_scanner.gif" width="480" alt="M Rakesh neon symbol scanner portrait" />
  <h2>⚡ Hey, I'm M Rakesh</h2>
  <p>AI & Machine Learning Student | Aspiring AI Engineer</p>
</div>
```
